Localización de Laravel 5.4 al español
===============


##Instrucciones:

1. Descargar la carpeta "es" y colocarla dentro de /resources/lang/

2. Luego abrir el archivo /config/app.php y editar la siguiente línea

        'locale' => 'en',

      por 
  
        'locale' => 'es',
